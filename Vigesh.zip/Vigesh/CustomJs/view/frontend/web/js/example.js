define([], function(config) {

alert('Hello...This is  Vigesh' );
console.log(config);
})