var config = {
    map: {
        '*': {
            'example-modal': 'Vigesh_CustomJs/js/example'
        }
    }
};