<?php


namespace Ves\FaceSupportLive\Model;

/**
 * Class UserData
 * @package Ves\FaceSupportLive\Model
 */
class UserData extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this-> _init('Ves\FaceSupportLive\Model\ResourceModel\UserData');
    }
}
