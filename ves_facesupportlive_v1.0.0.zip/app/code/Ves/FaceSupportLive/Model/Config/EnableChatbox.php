<?php

namespace Ves\FaceSupportLive\Model\Config;

/**
 * Class EnableChatbox
 * @package Ves\FaceSupportLive\Model\Config
 */
class EnableChatbox implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        // TODO: Implement toOptionArray() method.
        return [
            [
                'value' => '0',
                'label' => 'No',
            ],
            [
                'value' => '1',
                'label' => 'Yes',
            ],
        ];
    }
}
