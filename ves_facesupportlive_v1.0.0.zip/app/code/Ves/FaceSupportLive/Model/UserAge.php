<?php


namespace Ves\FaceSupportLive\Model;

class UserAge extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this-> _init('Ves\FaceSupportLive\Model\ResourceModel\UserAge');
    }
}
