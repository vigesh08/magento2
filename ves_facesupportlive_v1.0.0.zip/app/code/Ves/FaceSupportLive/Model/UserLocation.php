<?php


namespace Ves\FaceSupportLive\Model;

class UserLocation extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this-> _init('Ves\FaceSupportLive\Model\ResourceModel\UserLocation');
    }
}
