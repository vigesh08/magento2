<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 13/05/2017
 * Time: 09:40
 */
namespace Ves\FaceSupportLive\Model\ResourceModel;

/**
 * Class UserData
 * @package Ves\FaceSupportLive\Model\ResourceModel
 */
class UserData extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('ves_userdata', 'user_id');
    }
}
