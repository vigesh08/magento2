<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 20/05/2017
 * Time: 08:36
 */

namespace Ves\FaceSupportLive\Model\ResourceModel;

class UserAge extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('ves_userage', 'age_id');
    }
}
