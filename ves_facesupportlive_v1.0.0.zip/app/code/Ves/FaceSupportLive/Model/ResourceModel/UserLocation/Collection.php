<?php

namespace Ves\FaceSupportLive\Model\ResourceModel\UserLocation;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected function _construct()
    {
        $this->_init('Ves\FaceSupportLive\Model\UserLocation', 'Ves\FaceSupportLive\Model\ResourceModel\UserLocation');
    }
}
