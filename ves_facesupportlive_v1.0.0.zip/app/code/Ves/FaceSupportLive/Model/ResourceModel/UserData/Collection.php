<?php


namespace Ves\FaceSupportLive\Model\ResourceModel\UserData;

/**
 * Class Collection
 * @package Ves\FaceSupportLive\Model\ResourceModel\UserData
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected function _construct()
    {
        $this->_init('Ves\FaceSupportLive\Model\UserData', 'Ves\FaceSupportLive\Model\ResourceModel\UserData');
    }
}
