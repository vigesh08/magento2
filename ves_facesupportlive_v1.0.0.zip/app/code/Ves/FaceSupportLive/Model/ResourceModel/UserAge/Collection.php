<?php

namespace Ves\FaceSupportLive\Model\ResourceModel\UserAge;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected function _construct()
    {
        $this->_init('Ves\FaceSupportLive\Model\UserAge', 'Ves\FaceSupportLive\Model\ResourceModel\UserAge');
    }
}
