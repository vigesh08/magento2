<?php

namespace Ves\FaceSupportLive\Block\Chatbox;

class Dashboard extends \Magento\Backend\Block\Template
{
    /**
     * @var \Ves\FaceSupportLive\Model\UserAgeFactory
     */
    protected $_userAgeFactory;
    /**
     * @var \Ves\FaceSupportLive\Model\UserLocationFactory
     */
    protected $_userLocationFactory;

    /**
     * Dashboard constructor.
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Ves\FaceSupportLive\Model\UserAgeFactory $userAgeFactory
     * @param \Ves\FaceSupportLive\Model\UserLocationFactory $userLocationFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Ves\FaceSupportLive\Model\UserAgeFactory $userAgeFactory,
        \Ves\FaceSupportLive\Model\UserLocationFactory $userLocationFactory,
        array $data = []
    ) {
        $this->_userAgeFactory = $userAgeFactory;
        $this->_userLocationFactory = $userLocationFactory;
        parent::__construct($context, $data);
    }

    /**
     * @return array
     */
    public function getUserAge()
    {
        return $this->_userAgeFactory->create()->getCollection()->getData();
    }

    /**
     * @return array
     */
    public function getUserLocation()
    {
        return $this->_userLocationFactory->create()->getCollection()->getData();
    }

    /**
     * @return mixed
     */
    public function getStatUserAge()
    {
        $ageData = [];

        $datas = $this->getUserAge();

        foreach ($datas as $data) {
            $ageData[] = [$data['user_age'], (int)$data['total']];
        }

        return $this->getArrayJs($ageData);
    }

    /**
     * @return mixed
     */
    public function getStatUserLocation()
    {
        $locationData = [];
        $datas = $this->getUserLocation();

        foreach ($datas as $data) {
            $locationData[] = [$data['user_location'], (int)$data['total']];
        }

        return $this->getArrayJs($locationData);
    }

    /**
     * @param $string
     * @return mixed
     */
    public function getArrayJs($string)
    {
        $data = json_encode($string);

        $convert1 = str_replace("\"", "\'", $data);

        $convert2 = str_replace("\\", "", $convert1);

        return $convert2;
    }
}
