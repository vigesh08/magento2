<?php

namespace Ves\FaceSupportLive\Block\Chatbox;

use Magento\Framework\View\Element\Template;

/**
 * Class FacebookSupport
 * @package Ves\FaceSupportLive\Block\Chatbox
 */
class FacebookSupport extends Template implements \Magento\Widget\Block\BlockInterface
{

    /**
     * FacebookSupport constructor.
     * @param Template\Context $context
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);

        $my_template = "facebooksupport.phtml";
        if($this->hasData("template") && $this->getData("template")) {
            $my_template = $this->getData("template");
        } elseif(isset($data['template']) && $data['template']){
            $my_template = $data['template'];
        }
        if($my_template) {
            $this->setTemplate($my_template);
        }
       
    }

    /**
     * @return mixed
     */
    public function getLinkPage()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/link_page');
    }

    /**
     * @return mixed
     */
    public function getAppId()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/app_id_page');
    }

    /**
     * @return mixed
     */
    public function getTitleOpenTab()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/title_open');
    }

    /**
     * @return mixed
     */
    public function getTitleCloseTab()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/title_close');
    }

    /**
     * @return mixed
     */
    public function getTabColor()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/tab_color');
    }

    /**
     * @return mixed
     */
    public function getTextColor()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/text_color');
    }

    /**
     * @return mixed
     */
    public function getEnableShadow()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/enable_shadow');
    }

    /**
     * @return mixed
     */
    public function getEnableTimeline()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/enable_timeline');
    }

    /**
     * @return mixed
     */
    public function getEnableEvent()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/enable_event');
    }

     /**
     * @return mixed
     */
    public function getAvatarWidth()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/avatar_width');
    }

     /**
     * @return mixed
     */
    public function getAvatarHeight()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/avatar_height');
    }

    /**
     * @return mixed
     */
    public function getChatboxWidth()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/chatbox_width');
    }

    /**
     * @return mixed
     */
    public function getChatboxHeight()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/chatbox_height');
    }

    /**
     * @return mixed
     */
    public function getCountEvent()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/count_event');
    }

    /**
     * @return mixed
     */
    public function getEnableMessenger()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/enable_mess');
    }

    /**
     * @return mixed
     */
    public function getEnableChatbox()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/enable_fb');
    }

    /**
     * @return mixed
     */
    public function getEnableProductChatbox()
    {
        return $this->_scopeConfig->getValue('chatbox/general_setting/enable_fb_product');
    }

    /**
     * @return string
     */
    public function getDataUserUrl()
    {
        return $this->getUrl("facebooksupportlive/index/user");
    }
}
