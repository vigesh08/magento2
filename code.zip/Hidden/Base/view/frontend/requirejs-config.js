var config = {
    map: {
        '*': {
            baseowlcarousel: 'Hidden_Base/js/owl.carousel',
        }
    }
};