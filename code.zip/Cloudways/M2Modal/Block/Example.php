<?php

namespace Cloudways\M2Modal\Block;

class Example extends \Magento\Framework\View\Element\Template
{
    public function getContent() : string
    {
        return 'Hello I am Vigesh';
    }
}